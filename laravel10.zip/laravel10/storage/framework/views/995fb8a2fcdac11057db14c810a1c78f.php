<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <h3 class="page-title">
            Transaction
        </h3>
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <i class="fa fa-home"></i>
                    <a href="/">Home</a>
                    <i class="fa fa-angle-right"></i>
                </li>
                <li>
                    <a href="<?php echo e(route('transaction.index')); ?>">Transaction</a>
                </li>
                <li >
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <a href="#" onclick="showInfo()">
                        <i class="icon-bulb"></i></a>
                </li>

            </ul>
            <div class="page-toolbar">
                <div id="dashboard-report-range" class="pull-right tooltips btn btn-fit-height btn-primary" data-container="body" data-placement="bottom" data-original-title="Change dashboard date range">
                    <i class="icon-calendar"></i>&nbsp; <span class="thin uppercase visible-lg-inline-block"></span>&nbsp; <i class="fa fa-angle-down"></i>
                </div>
            </div>
        </div>
        <div class="container">
            <?php if(@session('status')): ?>
                <div class="alert alert-success"><?php echo e(session('status')); ?></div>
            <?php endif; ?>
            <h2>Transaction Table</h2>
            <p>The .table class adds basic styling (light padding and only horizontal dividers) to a table:</p>
            <a href="<?php echo e(route("transaction.create")); ?>" class="btn btn-success">+ New Transaction</a>
            <table class="table" >
                      <thead>
                      <tr>
                            <th>ID</th>
                            <th>Customer</th>
                            <th>Kasir</th>
                            <th>Tanggal Transaction</th>
                            <th>Action</th>
                          </tr>
                      </thead>
                      <tbody>
                      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                                <td><?php echo e($d->id); ?></td>
                                <td><?php echo e($d->customer->name); ?></td>
                                <td><?php echo e($d->user->name); ?></td>
                                <td><?php echo e($d->created_at); ?></td>
                                <td><a class="btn btn-default" data-toggle="modal" href="#myModal" onclick="getDetailData(<?php echo e($d->id); ?>);">Lihat Rincian Pembelian</a></td>
                              </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
        </div>
    </div>
    <div class="modal fade" id="myModal" tabindex="-1" role="basic" aria-hidden="true">
        <div class="modal-dialog modal-wide">
            <div class="modal-content" id="msg">
                <!--loading animated gif can put here-->
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
    <script>
        function getDetailData(id) {
            $.ajax({
                type:'POST',
                url:'<?php echo e(route("transaction.showAjax")); ?>',
                data:'_token= <?php echo csrf_token() ?> &id='+id,
                success:function(data) {
                    $("#msg").html(data.msg);
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.conquer2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Github\WFP_160421072\laravel10\resources\views/transaction/index.blade.php ENDPATH**/ ?>