<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
  <h4 class="modal-title">Products of hotel : <?php echo e($nama); ?></h4>
</div>
<div class="modal-body">
  <!--next slide -->
  <div class='row'>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class='col-md-4' style='border:1px solid #eee;text-align:center'>
        <img src="<?php echo e(asset($d->images)); ?>" height='200px' /></a> <br>
        <?php echo e($d->name); ?> <br>
        Rp. <?php echo e($d->price); ?>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

</div>
<div class="modal-footer">
  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
</div>
<?php /**PATH D:\Github\WFP_160421072\laravel10\resources\views/hotel/showProducts.blade.php ENDPATH**/ ?>