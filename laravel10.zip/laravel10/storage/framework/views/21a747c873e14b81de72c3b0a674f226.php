


<?php $__env->startSection('content'); ?>
<div class="modal fade" id="disclaimer" tabindex="-1" role="basic" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
          <h4 class="modal-title">DISCLAIMER</h4>
        </div>
        <div class="modal-body">
          Pictures shown are for illustration purpose only. Actual product may vary due to product enhancement.
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
   </div>
</div>
<div class="modal fade" id="myModal" tabindex="-1" role="basic" aria-hidden="true">
  <div class="modal-dialog modal-wide">
     <div class="modal-content" id="showproducts">
       <!--loading animated gif can put here-->
     </div>
  </div>
</div>
    <div class="page-content">
        <!-- BEGIN PAGE HEADER-->

        <h3 class="page-title">
            Hotel
        </h3>
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <i class="fa fa-home"></i>
                    <a href="/">Home</a>
                    <i class="fa fa-angle-right"></i>
                </li>
                <li>
                    <a href="#">Hotel</a>
                </li>
                <li >
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  <a href="#" onclick="showInfo()">
                  <i class="icon-bulb"></a></i>
               </li>

            </ul>
            <div class="page-toolbar">
                <div id="dashboard-report-range" class="pull-right tooltips btn btn-fit-height btn-primary" data-container="body" data-placement="bottom" data-original-title="Change dashboard date range">
                    <i class="icon-calendar"></i>&nbsp; <span class="thin uppercase visible-lg-inline-block"></span>&nbsp; <i class="fa fa-angle-down"></i>
                </div>
            </div>
        </div>

<div class="container">
  <h2>Hotel Table</h2>
  <p>The .table class adds basic styling (light padding and only horizontal dividers) to a table:</p>
  <a class="btn btn-warning" data-toggle="modal" href="#disclaimer">Disclaimer</a>
  <table class="table">
    <thead>
      <tr>
        <th>id</th>
        <th>name</th>
          <th>Logo Hotel</th>
        <th>address</th>
        <th>postcode</th>
        <th>city</th>
        <th>Detail</th>
        <th>Available Products</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $queryModel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($data ->id); ?></td>
        
        <td><?php echo e($data ->name); ?></td>
          <td>
              <img height='100px' src="<?php echo e(asset('/logo/'.$data->id.'.jpg')); ?>"/><br>
              <a href="<?php echo e(url('hotel/uploadLogo/'.$data->id)); ?>">
                  <button class='btn btn-xs btn-default'>upload</button></a><br>
              <img height='100px' src="<?php echo e(asset('/images/'.$data->image)); ?>"/><br>
              <a href="<?php echo e(url('hotel/uploadPhoto/'.$data->id)); ?>">
                  <button class='btn btn-xs btn-default'>upload Database</button></a>
          </td>
          <td><?php echo e($data ->address); ?></td>
        <td><?php echo e($data ->postcode); ?></td>
        <td><?php echo e($data ->city); ?></td>
        <td>
          <a class="btn btn-info"  href="#detail_<?php echo e($data->id); ?>" data-toggle="modal"><?php echo e($data->name); ?></a>

                    <div class="modal fade" id="detail_<?php echo e($data->id); ?>" tabindex="-1" role="basic" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h4 class="modal-title"><?php echo e($data->name); ?></h4>
                                </div>
                                <div class="modal-body">
                                    <img src=<?php echo e(asset('images/'.$data->image)); ?> height='200px' width='200px'/>
                                </div>
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                </div>
                              </div>
                        </div>
                    </div>

        </td>
        <td>
          <ul>
            <?php $__currentLoopData = $data->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($item->name); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <a class='btn btn-xs btn-info' data-toggle='modal' data-target='#myModal'onclick='showProducts(<?php echo e($data->id); ?>)'>List Product</a>
          </ul>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
    <br>

    <div class="row">
        <?php $__currentLoopData = $queryModel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-3"
                 style="border:1px solid #999;padding:10px;margin:10px;text-align:center;
            border-radius:10px">
                <img height="100px" src="<?php echo e(asset('images/'.$d->image)); ?>" />
                <br><?php echo e($d->name); ?>

                <br><?php echo e($d->address); ?>, <?php echo e($d->city); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script>
function showProducts(hotel_id)
{
  $.ajax({
    type:'POST',
    url:'<?php echo e(route("hotel.showProducts")); ?>',
    data:{'_token':'<?php echo csrf_token() ?>',
          'hotel_id':hotel_id
         },
    success: function(data){
       $('#showproducts').html(data.msg)
    }
  });
}
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.conquer2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Github\WFP_160421072\laravel10\resources\views/hotel/index.blade.php ENDPATH**/ ?>