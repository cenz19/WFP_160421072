

<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <!-- BEGIN PAGE HEADER-->
        <h3 class="page-title">
            Product
        </h3>
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <i class="fa fa-home"></i>
                    <a href="/">Home</a>
                    <i class="fa fa-angle-right"></i>
                </li>
                <li>
                    <a href="#">Product</a>
                </li>
            </ul>
            <div class="page-toolbar">
                <div id="dashboard-report-range" class="pull-right tooltips btn btn-fit-height btn-primary" data-container="body" data-placement="bottom" data-original-title="Change dashboard date range">
                    <i class="icon-calendar"></i>&nbsp; <span class="thin uppercase visible-lg-inline-block"></span>&nbsp; <i class="fa fa-angle-down"></i>
                </div>
            </div>
        </div>
        <div class="container">
            <?php if(@session('status')): ?>
                <div class="alert alert-success"><?php echo e(session('status')); ?></div>
            <?php endif; ?>
            <a href="<?php echo e(route("product.create")); ?>" class="btn btn-success">+ New Type</a>
            <h2>Product Table</h2>
            <p>The .table class adds basic styling (light padding and only horizontal dividers) to a table:</p>
            <table class="table">
                <thead>
                <tr>
                    <th>id</th>


                    <th>Product Images</th>
                    <th>name</th>
                    <th>price</th>
                    <th>hotel_id</th>
                    <th>hotel</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $queryModel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($data ->id); ?></td>
                      <td>
                          <?php if($data->filenames): ?>
                              <?php $__currentLoopData = $data->filenames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filename): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <img width="100" height="100" src="<?php echo e(asset('product_image/'.$data->id.'/'.$filename)); ?>"/><br>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php endif; ?>













                      </td>
                    <td><?php echo e($data ->name); ?></td>
                    <td><?php echo e($data ->price); ?></td>
                    <td><?php echo e($data ->hotel_id); ?></td>

                    <td><?php echo e($data ->hotels->name); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.conquer2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Github\WFP_160421072\laravel10\resources\views/product/index.blade.php ENDPATH**/ ?>