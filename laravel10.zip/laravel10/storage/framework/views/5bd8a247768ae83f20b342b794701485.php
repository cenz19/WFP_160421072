<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <h3 class="page-title">Upload Logo untuk hotel <?php echo e($hotel->name); ?></h3>
        <div class="container">
            <form method="POST" enctype="multipart/form-data" action="<?php echo e(url('hotel/simpanPhoto')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="exampleInputType">Pilih Logo</label>
                    <input type="file" class="form-control" name="file_photo"/>
                    <input type="hidden" name='hotel_id' value="<?php echo e($hotel->id); ?>"/>
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.conquer2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Github\WFP_160421072\laravel10\resources\views/hotel/formUploadPhoto.blade.php ENDPATH**/ ?>